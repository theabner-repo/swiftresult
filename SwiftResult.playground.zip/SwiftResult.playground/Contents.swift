import Foundation

enum MyErrors: Error {
    case noData
    case badURL
}

struct CustomModel: Codable {
    // Implementation
}

func request<Model: Codable>(_ model: Model.Type, with completion: @escaping (Result<Model, Error>) -> ()) {
    
    
    let request = URLRequest(url: URL(string: "www.google.com")!)
    
    URLSession.shared.dataTask(with: request) { (data, response, error) in
        
        if let error = error {
            completion(.failure(error))
        } else if let data = data {
            do {
                let resultModel = try JSONDecoder().decode(Model.self, from: data)
                completion(.success(resultModel))
            } catch {
                completion(.failure(error))
            }
        } else {
            completion(.failure(MyErrors.noData))
        }
        
    }.resume()
    
}


request(CustomModel.self) { (result) in
    
    switch result {
    case .success(let customModel):
        break
    case .failure(let error):
        break
    }
    
}

func fetch(from urlString: String, completionHandler: @escaping (Result<Int, MyErrors>) -> Void)  {
    guard let url = URL(string: urlString) else {
        completionHandler(.failure(.badURL))
        return
    }

    print("Fetching \(url.absoluteString)...")
    completionHandler(.success(5))
}

fetch(from: "A bad url") { (result) in
    
    switch result {
    case .success(let number):
        print(number)
    case .failure(let error):
        switch error {
        case .badURL:
            // Caso par cuando la url falle
            break
        case .noData:
            // Caso para cuando no haya datos
            break
        }
    }
    
}

// MARK: - También podemos devolver Results
enum FactorError: Error {
    case belowMinimum
    case isPrime
}

func generateRandomNumber(maximum: Int) -> Result<Int, FactorError> {
    if maximum < 0 {
        // creating a range below 0 will crash, so refuse
        return .failure(.belowMinimum)
    } else {
        let number = Int.random(in: 0...maximum)
        return .success(number)
    }
}

let result1 = generateRandomNumber(maximum: 11)
switch result1 {
case .failure(let error):
    switch error {
    case .isPrime:
        print("El número es primo")
    case .belowMinimum:
        print("Está por debajo del mínimo")
    }
case .success(let numero):
    print("El número es \(numero)")
}
